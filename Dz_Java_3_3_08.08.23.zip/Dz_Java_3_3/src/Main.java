import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scr = new Scanner(System.in);
        System.out.println("Введите первое целое число number1: ");
        int number1 = scr.nextInt();
        System.out.println("Введите второе целое число number2 : ");
        int number2 = scr.nextInt();
        System.out.println("number1 + number1 = " + (number1 + number2));
        System.out.println("number1 - number1 = " + (number1 - number2));
        System.out.println("number1 * number1 = " + (number1 * number2));
        System.out.println("number1 / number1 = " + (number1 / number2));


    }
}