import java.util.Random;

public class Main {
    public static void main(String[] args) {
        System.out.println("Задание1.1");
        Random rnd = new Random();
        int i1 = rnd.nextInt();
        System.out.println("int "+i1);
        short sh1 = (short) i1;
        System.out.println("short "+sh1);
        int i2 = rnd.nextInt();
        byte b1 = (byte)i2;
        System.out.println("byte "+b1);
        long lo1 = rnd.nextLong();
        System.out.println("long "+lo1);
        float fl1 = rnd.nextFloat();
        System.out.println("float "+fl1);
        double db1 = rnd.nextDouble();
        System.out.println("double "+db1);
        boolean isok = rnd.nextBoolean();
        System.out.println("boolean "+isok);
        char ch1 = (char) rnd.nextInt('A','Z'+1);
        System.out.println("char "+ch1);
        System.out.println();
        System.out.println("Задание1.2");
        String st1 = i1 +"";
        System.out.println(st1);
        String st2 = String.valueOf((char)rnd.nextInt('A','Z'+1)) + String.valueOf((char)rnd.nextInt('A','Z'+1)) + String.valueOf((char)rnd.nextInt('A','Z'+1));
        System.out.println(st2);

        





    }
}