import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        // Напишите программу, которая принимает от пользователя его имя, возраст (полных лет) и вес.
        // Когда все данные введены, программа должна выдать сообщение: «Уважаемый, [Имя]! В свои [Возраст] лет Вы для нас дороги, как [Вес] килограмм золота.».
        // В сообщении [Имя], [Возраст] и [Вес] должны принять введённые значения.
        Scanner scr = new Scanner(System.in);
        System.out.print("Введите ваше имя: ");
        String name = scr.nextLine();
        System.out.println("Введите свой возраст: ");
        int age = scr.nextInt();
        System.out.println("Введите свой вес: ");
        int weigh = scr.nextInt();
        System.out.println("Уважаемый, " + name + "! В свои " + age + " лет Вы для нас дороги, как " + weigh + " килограмм золота.");
    }
}
